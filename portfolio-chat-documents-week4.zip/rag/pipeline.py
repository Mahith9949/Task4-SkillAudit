import os, re, io
from pathlib import Path
try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None
try:
    from sentence_transformers import SentenceTransformer, CrossEncoder
except Exception:
    SentenceTransformer = CrossEncoder = None
try:
    import chromadb
except Exception:
    chromadb = None
try:
    from google import genai
except Exception:
    genai = None

SAMPLES = {
"rag_intro.md": "# RAG Overview\\nRAG combines semantic retrieval with language-model generation. It loads documents, splits them into overlapping chunks, creates embeddings, retrieves relevant passages, and uses those passages as context to ground answers.",
"reranking.md": "# Re-ranking\\nA retriever can return ten candidate chunks. A cross-encoder scores the question and each passage together, sorts candidates by relevance, and selects the best three or four chunks before answer generation.",
"query_rewriting.md": "# Query Rewriting\\nA multi-part question can be split into focused sub-questions. Each sub-question is searched independently and the results are combined before answering. This helps vague questions and questions that ask for several facts.",
"chunking.md": "# Chunking\\nChunking splits long documents into smaller passages. Overlap repeats some words between adjacent chunks to preserve context at boundaries. Chunk size should be tested against the documents and questions.",
"vector_stores.md": "# Vector Stores\\nA vector store keeps document chunks, embeddings, and metadata. Similarity search returns passages close to a question embedding. ChromaDB can run locally in persistent mode for portfolio projects."
}

class RAGPipeline:
    def __init__(self):
        self.chunks = []
        self.embedder = None
        self.reranker = None
        self.collection = None
        if SentenceTransformer:
            try: self.embedder = SentenceTransformer(os.getenv("EMBEDDING_MODEL","sentence-transformers/all-MiniLM-L6-v2"))
            except Exception: pass
        if CrossEncoder:
            try: self.reranker = CrossEncoder(os.getenv("RERANKER_MODEL","cross-encoder/ms-marco-MiniLM-L-6-v2"))
            except Exception: pass
        if chromadb:
            try:
                client = chromadb.PersistentClient(path=os.getenv("CHROMA_PATH","./chroma_db"))
                self.collection = client.get_or_create_collection("week4_docs")
            except Exception: pass

    def _chunks(self, text, size=450, overlap=60):
        words = text.split()
        out, start = [], 0
        while start < len(words):
            end = min(start+size, len(words))
            out.append(" ".join(words[start:end]))
            if end == len(words): break
            start = max(start+1, end-overlap)
        return out

    def _add(self, source, text, kind):
        for n, part in enumerate(self._chunks(text)):
            self.chunks.append({"text":part,"source":source,"source_type":kind,"chunk":n})
        return len(self._chunks(text))

    def add_sample_documents(self):
        self.chunks = []
        total = 0
        for name, text in SAMPLES.items():
            total += self._add(name, text, "markdown")
        self._sync()
        return total

    def _read(self, upload):
        name, raw = upload.name, upload.getvalue()
        ext = Path(name).suffix.lower()
        if ext == ".pdf":
            if not PdfReader: return ""
            try: return "\\n".join(p.extract_text() or "" for p in PdfReader(io.BytesIO(raw)).pages)
            except Exception: return ""
        return raw.decode("utf-8", errors="ignore")

    def add_uploads(self, uploads):
        total = 0
        for u in uploads:
            txt = self._read(u)
            if txt.strip(): total += self._add(u.name, txt, Path(u.name).suffix.lower().lstrip("."))
        self._sync()
        return total

    def _sync(self):
        if self.collection and self.chunks:
            try:
                embs = self.embedder.encode([c["text"] for c in self.chunks]).tolist() if self.embedder else None
                args = dict(ids=[f"c{i}" for i in range(len(self.chunks))],
                            documents=[c["text"] for c in self.chunks],
                            metadatas=[{"source":c["source"],"source_type":c["source_type"],"chunk":c["chunk"]} for c in self.chunks])
                if embs: args["embeddings"] = embs
                self.collection.upsert(**args)
            except Exception: pass

    def _retrieve(self, q, top=10):
        if not self.chunks: self.add_sample_documents()
        if self.collection and self.embedder:
            try:
                res = self.collection.query(query_embeddings=self.embedder.encode([q]).tolist(), n_results=min(top,len(self.chunks)))
                return [{"text":d,"source":m.get("source","unknown"),"source_type":m.get("source_type","unknown"),"score":1-float(dist)}
                        for d,m,dist in zip(res["documents"][0],res["metadatas"][0],res["distances"][0])]
            except Exception: pass
        terms = set(re.findall(r"\\w+", q.lower()))
        ranked=[]
        for c in self.chunks:
            words=set(re.findall(r"\\w+",c["text"].lower()))
            ranked.append({**c,"score":len(terms & words)/max(1,len(terms))})
        return sorted(ranked,key=lambda c:c["score"],reverse=True)[:top]

    def _rerank(self, q, candidates):
        method = "lexical fallback"
        if self.reranker and candidates:
            try:
                scores=self.reranker.predict([[q,c["text"]] for c in candidates])
                candidates=[{**c,"rerank_score":float(s)} for c,s in zip(candidates,scores)]
                candidates.sort(key=lambda c:c["rerank_score"],reverse=True)
                method="cross-encoder/ms-marco-MiniLM-L-6-v2"
            except Exception: pass
        else:
            candidates.sort(key=lambda c:c.get("score",0),reverse=True)
        return candidates[:4],method

    def _answer(self, q, context):
        key=os.getenv("GEMINI_API_KEY","").strip()
        if key and genai:
            try:
                client=genai.Client(api_key=key)
                prompt=("Answer using only the context. If the context lacks evidence, say so. Cite source filenames.\\n\\n"
                        f"CONTEXT:\\n{context}\\n\\nQUESTION: {q}")
                r=client.models.generate_content(model=os.getenv("GEMINI_MODEL","gemini-2.5-flash"),contents=prompt)
                if r.text: return r.text.strip(),"Gemini API"
            except Exception: pass
        if not context.strip(): return "I couldn't find enough evidence in the indexed documents.","local fallback"
        return "Based on the retrieved excerpts: "+context[:650]+"\\n\\n[Demo fallback: configure GEMINI_API_KEY for a generated answer.]","local demo fallback"

    def answer(self, question):
        trace=[]
        if re.fullmatch(r"\\s*(what is|calculate|compute)?\\s*\\d+\\s*[+*/-]\\s*\\d+\\s*\\??\\s*",question.lower()):
            expr=re.sub(r"[^0-9+*/(). -]","",question)
            try: ans=str(eval(expr,{"__builtins__":{}},{}))
            except Exception: ans="I can answer this directly."
            return {"answer":ans,"trace":"ROUTER: answer_directly\\nRETRIEVAL: skipped (simple arithmetic)"}
        trace.append("ROUTER: needs_retrieval")
        queries=[question]
        if re.search(r"\\b(compare|difference|versus| vs | and )\\b",question.lower()):
            parts=[p.strip(" ?.") for p in re.split(r"\\band\\b|,|versus|vs\\.? ",question,flags=re.I) if len(p.strip())>5]
            if len(parts)>1:
                queries=parts[:2]
                trace.append("QUERY REWRITE: split into sub-queries")
                trace.extend("  - "+q for q in queries)
        candidates=[]
        for q in queries: candidates.extend(self._retrieve(q,10))
        unique=[]; seen=set()
        for c in candidates:
            k=(c["source"],c["text"])
            if k not in seen: unique.append(c); seen.add(k)
        trace.append(f"RETRIEVAL: {len(unique)} candidate chunks")
        selected,method=self._rerank(question,unique)
        trace.append("RERANKER: "+method)
        context="\\n\\n".join(f"[{c['source']}] {c['text']}" for c in selected)
        trace.append(f"CONTEXT: {len(selected)} chunks sent to answer generator")
        ans,provider=self._answer(question,context)
        trace.append("ANSWER PROVIDER: "+provider)
        trace.append("SOURCES: "+", ".join(c["source"] for c in selected))
        trace.append("RETRIEVED CHUNKS:")
        trace.extend(f"[{i}] {c['source']}: {c['text'][:220]}" for i,c in enumerate(selected,1))
        return {"answer":ans,"trace":"\\n".join(trace)}
