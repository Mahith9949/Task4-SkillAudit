# DocuChat — Week 4 Portfolio App

Streamlit chat UI for asking questions about uploaded documents. It shows routing decisions, query rewriting, retrieved evidence, re-ranking method, and answer source.

## Architecture

```text
Upload PDF/TXT/MD/CSV -> Extract text -> Overlapping chunks + metadata
  -> Embeddings / local ChromaDB (when installed)
  -> Question router
      -> simple arithmetic: direct answer, no retrieval
      -> document question: retrieve up to 10 candidates
         -> optional query rewriting for multi-part questions
         -> cross-encoder re-ranking -> best 4 chunks
         -> Gemini API (if configured) or labelled demo fallback
  -> Answer + trace + sources in Streamlit UI
```

## Run
1. `python -m venv .venv`
2. Activate the environment.
3. `pip install -r requirements.txt`
4. Copy `.env.example` to `.env`; optionally add `GEMINI_API_KEY`.
5. `streamlit run app.py`
6. Click **Load sample documents** and ask questions.

Try:
- `What is 2 + 2?` — direct answer without retrieval.
- `Explain RAG and re-ranking` — retrieval and ranking.
- `Compare query rewriting and vector stores` — query rewrite + retrieval.

The fallback answer is not an LLM response. First-time model installs may download models. Keep `.env` private.
