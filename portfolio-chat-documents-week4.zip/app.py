import streamlit as st
from dotenv import load_dotenv
from rag.pipeline import RAGPipeline

load_dotenv()
st.set_page_config(page_title="DocuChat | Agentic RAG", page_icon="📚", layout="wide")
st.title("📚 DocuChat — Chat With Your Documents")
st.caption("Week 4 portfolio app · Multi-source retrieval · Re-ranking · Agent decisions")

@st.cache_resource
def pipeline():
    return RAGPipeline()

rag = pipeline()
with st.sidebar:
    st.header("📄 Documents")
    uploads = st.file_uploader("Upload PDF, TXT, MD or CSV", type=["pdf","txt","md","csv"], accept_multiple_files=True)
    if st.button("Index uploaded documents", type="primary"):
        if uploads:
            st.success(f"Indexed {rag.add_uploads(uploads)} chunks.")
        else:
            st.warning("Choose files first.")
    if st.button("Load sample documents"):
        st.success(f"Loaded {rag.add_sample_documents()} chunks.")
    st.caption("Optional: configure GEMINI_API_KEY in .env for real LLM answers.")

if "history" not in st.session_state:
    st.session_state.history = []
for item in st.session_state.history:
    with st.chat_message(item["role"]):
        st.markdown(item["content"])
        if item.get("trace"):
            with st.expander("Agent decisions & retrieved evidence"):
                st.code(item["trace"])

question = st.chat_input("Ask something about your documents...")
if question:
    st.session_state.history.append({"role":"user","content":question})
    with st.chat_message("user"):
        st.markdown(question)
    result = rag.answer(question)
    with st.chat_message("assistant"):
        st.markdown(result["answer"])
        with st.expander("Agent decisions & retrieved evidence", expanded=True):
            st.code(result["trace"])
    st.session_state.history.append({"role":"assistant","content":result["answer"],"trace":result["trace"]})
